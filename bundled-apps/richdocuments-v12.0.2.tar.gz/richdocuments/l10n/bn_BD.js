OC.L10N.register(
    "richdocuments",
    {
    "Saved" : "সংরক্ষণ করা হলো",
    "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form" : "আপলোড করা ফাইলটি  HTML  ফর্মে উল্লিখিত MAX_FILE_SIZE নির্ধারিত ফাইলের সর্বোচ্চ আকার  অতিক্রম করতে চলেছে ",
    "No file was uploaded" : "কোন ফাইল আপলোড করা হয় নি",
    "Missing a temporary folder" : "অস্থায়ী ফোল্ডারটি হারানো গিয়েছে",
    "New" : "নতুন",
    "Select groups" : "গ্রুপ নির্ধারণ",
    "Cancel" : "বাতির",
    "Save" : "সংরক্ষণ",
    "Create" : "তৈরী কর",
    "Description" : "বিবরণ",
    "Edit" : "সম্পাদনা",
    "Close" : "বন্ধ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "বিসতারিত",
    "Download" : "ডাউনলোড"
},
"nplurals=2; plural=(n != 1);");
