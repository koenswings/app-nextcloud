OC.L10N.register(
    "richdocuments",
    {
    "File already exists" : "ගොනුව දැනටමත් පවතී",
    "No file was uploaded" : "කිසිදු ගොනුවක් උඩුගත කර නොමැත",
    "Missing a temporary folder" : "තාවකාලික බහාලුමක් අස්ථානගත වී ඇත",
    "Images" : "පින්තූර",
    "Empty" : "හිස්",
    "New" : "නව",
    "Confirm" : "තහවුරු කරන්න",
    "Cancel" : "අවලංගු කරන්න",
    "Save" : "සුරකින්න",
    "File name" : "ගොනුවේ නම",
    "Create" : "සාදන්න",
    "Description" : "විස්තරය",
    "No results" : "ප්‍රතිථල නැත",
    "Preview" : "පෙරදසුන",
    "Edit" : "සංස්කරණය",
    "Close" : "වසන්න",
    "Details" : "විස්තර",
    "Download" : "බාගන්න",
    "New file" : "නව ගොනුව"
},
"nplurals=2; plural=(n != 1);");
