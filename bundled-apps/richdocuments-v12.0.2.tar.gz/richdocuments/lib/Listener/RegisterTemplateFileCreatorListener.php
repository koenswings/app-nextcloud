<?php

declare(strict_types=1);
/**
 * SPDX-FileCopyrightText: 2022 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

namespace OCA\Richdocuments\Listener;

use OCA\Richdocuments\AppInfo\Application;
use OCA\Richdocuments\PermissionManager;
use OCA\Richdocuments\Service\CapabilitiesService;
use OCP\App\IAppManager;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;
use OCP\Files\Template\RegisterTemplateCreatorEvent;
use OCP\Files\Template\TemplateFileCreator;
use OCP\IConfig;
use OCP\IL10N;

/** @template-implements IEventListener<Event|RegisterTemplateCreatorEvent> */
class RegisterTemplateFileCreatorListener implements IEventListener {
	public function __construct(
		private IL10N $l10n,
		private IConfig $config,
		private IAppManager $appManager,
		private CapabilitiesService $capabilitiesService,
		private PermissionManager $permissionManager,
	) {
	}

	#[\Override]
	public function handle(Event $event): void {
		if (!$event instanceof RegisterTemplateCreatorEvent) {
			return;
		}

		if (empty($this->capabilitiesService->getCapabilities())) {
			return;
		}

		$user = $this->permissionManager->loggedInUser();
		$userCanCreate = $this->permissionManager->isEnabledForUser($user) && $this->permissionManager->userCanEdit($user);
		if ($user && !$userCanCreate) {
			return;
		}

		$templateManager = $event->getTemplateManager();
		$ooxml = $this->config->getAppValue(Application::APPNAME, 'doc_format', 'ooxml') === 'ooxml';
		$appPath = $this->appManager->getAppPath('richdocuments');

		$templateManager->registerTemplateFileCreator(function () use ($ooxml, $appPath) {
			$odtType = new TemplateFileCreator('richdocuments', $this->l10n->t('Document'), ($ooxml ? '.docx' : '.odt'));
			if ($ooxml) {
				$odtType->addMimetype('application/msword');
				$odtType->addMimetype('application/vnd.openxmlformats-officedocument.wordprocessingml.document');
			} else {
				$odtType->addMimetype('application/vnd.oasis.opendocument.text');
				$odtType->addMimetype('application/vnd.oasis.opendocument.text-template');
			}
			$odtType->setIconSvgInline(file_get_contents($appPath . '/img/x-office-document.svg'));
			$odtType->setRatio((float)21 / 29.7);
			$odtType->setOrder(-30);
			return $odtType;
		});
		$templateManager->registerTemplateFileCreator(function () use ($ooxml, $appPath) {
			$odsType = new TemplateFileCreator('richdocuments', $this->l10n->t('Spreadsheet'), ($ooxml ? '.xlsx' : '.ods'));
			if ($ooxml) {
				$odsType->addMimetype('application/vnd.ms-excel');
				$odsType->addMimetype('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
			} else {
				$odsType->addMimetype('application/vnd.oasis.opendocument.spreadsheet');
				$odsType->addMimetype('application/vnd.oasis.opendocument.spreadsheet-template');
			}
			$odsType->setIconSvgInline(file_get_contents($appPath . '/img/x-office-spreadsheet.svg'));
			$odsType->setRatio(16 / 9);
			$odsType->setOrder(-20);
			return $odsType;
		});
		$templateManager->registerTemplateFileCreator(function () use ($ooxml, $appPath) {
			$odpType = new TemplateFileCreator('richdocuments', $this->l10n->t('Presentation'), ($ooxml ? '.pptx' : '.odp'));
			if ($ooxml) {
				$odpType->addMimetype('application/vnd.ms-powerpoint');
				$odpType->addMimetype('application/vnd.openxmlformats-officedocument.presentationml.presentation');
			} else {
				$odpType->addMimetype('application/vnd.oasis.opendocument.presentation');
				$odpType->addMimetype('application/vnd.oasis.opendocument.presentation-template');
			}
			$odpType->setIconSvgInline(file_get_contents($appPath . '/img/x-office-presentation.svg'));
			$odpType->setRatio(16 / 9);
			$odpType->setOrder(-10);
			return $odpType;
		});

		$templateManager->registerTemplateFileCreator(function () use ($appPath) {
			$odgType = new TemplateFileCreator('richdocuments', $this->l10n->t('Diagram'), '.odg');
			$odgType->addMimetype('application/vnd.oasis.opendocument.graphics');
			$odgType->addMimetype('application/vnd.oasis.opendocument.graphics-template');
			$odgType->setIconSvgInline(file_get_contents($appPath . '/img/x-office-drawing.svg'));
			$odgType->setRatio(1);
			return $odgType;
		});
	}
}
