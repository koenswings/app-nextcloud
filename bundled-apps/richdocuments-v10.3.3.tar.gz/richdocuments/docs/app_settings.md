<!--
  - SPDX-FileCopyrightText: 2018 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: AGPL-3.0-or-later
-->
## Nextcloud Office App Settings

### Collabora Online Server
URL (and port) of the Collabora Online server that provides the editing functionality as a WOPI client. Collabora Online should use the same protocol (http:// or https://) as the server installation. Naturally, https:// is recommended.

### Restrict usage to specific groups
By default the app is enabled for all. When this setting is active, only members of specified groups can use Nextcloud Office.

### Restrict edit to specific groups
By default all users can edit documents with Nextcloud Office. When this setting is active, only the members of specified groups can edit, others can only view documents.

### Use OOXML by default for new files
By default new files created by users are in OpenDocument Format (ODF). When this setting is active, new files will be created in Office Open XML (OOXML) format.

### Enable access for external apps
Nextcloud internally passes an access token to Collabora Online that is used later by it to do various operations. By default, it's not possible to generate this token by 3rd parties; only Nextcloud can generate and pass it to Collabora Online.

In some applications, it might be necessary to generate the token by a 3rd party application. For this, one needs to add the 3rd party application (external apps) in this setting. You need to add an application identifier and a secret
token. These credentials then can be used by the 3rd party application to make calls to `wopi/extapp/data/{fileId}` to fetch the access token and URL source for given fileId, both required to open a connection to Collabora Online.

### Canonical webroot
Canonical webroot, in case there are multiple, for Collabora Online to use. Provide the one with least restrictions. E.g.: Use non-shibbolized webroot if this instance is accessed by both shibbolized and non-shibbolized webroots. You can ignore this setting if only one webroot is used to access this instance.

### Theme

By default Nextcloud Office comes with Nextcloud theme (monochrome icons following Nextcloud style), to change to a more traditional office look:

	occ config:app:set richdocuments theme --value="collabora"

To go back to default theme:

	occ config:app:set richdocuments theme --value="nextcloud"

### Previews

By default Nextcloud will generate previews of Office files using the Collabora file conversion endpoint. This can be turned off through

	occ config:app:set richdocuments preview_generation --type boolean --lazy --value false

The timeout for preview conversion requests (in seconds) can be configured. The default is 5 seconds:

	occ config:app:set richdocuments preview_conversion_timeout --type integer --value 10

Files larger than the configured maximum file size will be skipped and no preview will be generated. The default limit is 100 MB (104857600 bytes):

	occ config:app:set richdocuments preview_conversion_max_filesize --type integer --value 52428800

### Electronic signature
From a shell running in the Nextcloud root directory, run the following `occ`
command to configure a non-default base URL for eID Easy. For example:

	occ config:app:set richdocuments esignature_base_url --type string --value https://test.eideasy.com 

The eID Easy client ID and secret are instance wide admin credentials. Collabora Online uses them server side and never passes the secret on to the browser, so Nextcloud only includes them in a `CheckFileInfo` response when the request can be verified to originate from the Collabora server. The WOPI access token is no such proof, as the same token is handed to the browser to load the document.

A request is verified when Collabora Online publishes a WOPI proof key in its discovery and sends a valid proof. Generate the key on the Collabora Online server with:

	sudo coolconfig generate-proof-key

Alternatively the remote address of the request has to match the configured WOPI allow list:

	occ config:app:set richdocuments wopi_allowlist --value "192.168.1.0/24"

The proof key is the better option of the two, as the allow list compares IP addresses and therefore cannot tell Collabora Online apart from a user when both reach Nextcloud from the same address.

When neither is configured, the electronic signature settings are left out of the response, electronic signatures stay unavailable in the editor and a warning is written to the Nextcloud log.

### UI mode

Switching between classic and tabbed view is possible as a default, however users can still change this while using Office:

	occ config:app:set richdocuments uiDefaults-UIMode --type string --value classic

### Disable local editing

In case no desktop client is used on an instance you may disable the local editing button within office with:

	occ config:app:set richdocuments open_local_editor --type string --value no
